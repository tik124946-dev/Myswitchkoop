package com.nromaker;

import android.content.Intent;
import android.net.Uri;
import android.text.InputType;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import java.io.File;
import java.util.Locale;

/** Экран 3: игра из APK → NRO. Работает только для игр на LÖVE (Lua), остальное объясняет честно. */
final class ApkToNroScreen extends Screen {

    private static final int REQ_APK = 1, REQ_SAVE = 2;

    private File apk;
    private ApkInspector.Info info;
    private String apkName = "game";
    private volatile boolean busy;

    private TextView summary, status;
    private EditText nameEt, authorEt, versionEt;
    private ProgressBar bar;
    private Button apkBtn, buildBtn;

    ApkToNroScreen(MainActivity act) { super(act); }

    @Override String title() { return "APK → NRO"; }

    @Override boolean isBusy() { return busy; }

    @Override
    void fill(LinearLayout col) {
        Ui.add(col, Ui.text(act,
                "Приложение разбирает APK и смотрит, на чём сделана игра.\n\n"
                + "Что получится: игры на LÖVE (Lua) собираются в настоящий .nro — игра лежит внутри "
                + "APK открыто, и её можно запустить на встроенном движке LÖVE Potion.\n\n"
                + "Что не получится: игры на Unity, Godot, Unreal и обычные Android-приложения. "
                + "Их код скомпилирован под Android, а на Switch нет ни Android, ни Java. "
                + "Конвертера для них не существует, и приложение прямо скажет, почему.\n\n"
                + "Мобильные игры часто рассчитаны на касание экрана, поэтому управление геймпадом "
                + "может потребовать правок в коде игры.", 14), 8);

        apkBtn = Ui.button(act, "1. Выбрать APK", v -> {
            if (!busy) act.pick(REQ_APK, "*/*");
        });
        Ui.add(col, apkBtn, 12);

        summary = Ui.text(act, "APK не выбран", 14);
        Ui.add(col, summary, 4);

        nameEt = field("Название");
        authorEt = field("Автор");
        versionEt = field("Версия");
        Ui.add(col, nameEt, 4);
        Ui.add(col, authorEt, 0);
        Ui.add(col, versionEt, 0);
        nameEt.setVisibility(View.GONE);
        authorEt.setVisibility(View.GONE);
        versionEt.setVisibility(View.GONE);

        buildBtn = Ui.button(act, "2. Собрать и сохранить .nro", v -> askSave());
        buildBtn.setEnabled(false);
        Ui.add(col, buildBtn, 8);

        bar = new ProgressBar(act, null, android.R.attr.progressBarStyleHorizontal);
        bar.setMax(1000);
        bar.setVisibility(View.GONE);
        Ui.add(col, bar, 4);

        status = Ui.text(act, "", 14);
        Ui.add(col, status, 8);
    }

    private EditText field(String hint) {
        EditText e = new EditText(act);
        e.setHint(hint);
        e.setInputType(InputType.TYPE_CLASS_TEXT);
        return e;
    }

    private void setBusy(boolean b) {
        busy = b;
        apkBtn.setEnabled(!b);
        buildBtn.setEnabled(!b && info != null && info.convertible);
        bar.setVisibility(b ? View.VISIBLE : View.GONE);
    }

    private void fail(Throwable e) {
        bar.setIndeterminate(false);
        setBusy(false);
        String m = e.getMessage();
        status.setText("Ошибка: " + (m == null ? e.getClass().getSimpleName() : m));
    }

    @Override
    void onResult(int req, int res, Intent data) {
        if (res != android.app.Activity.RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        if (req == REQ_APK) onApkPicked(uri);
        else if (req == REQ_SAVE) onSavePicked(uri);
    }

    private void onApkPicked(Uri uri) {
        String n = act.displayName(uri);
        apkName = n == null ? "game" : n.replaceAll("(?i)\\.apk$", "");
        info = null;
        setBusy(true);
        bar.setIndeterminate(true);
        status.setText("Читаю APK…");
        summary.setText("");
        nameEt.setVisibility(View.GONE);
        authorEt.setVisibility(View.GONE);
        versionEt.setVisibility(View.GONE);
        new Thread(() -> {
            try {
                File f = act.copyToCache(uri, "input.apk");
                ApkInspector.Info i = ApkInspector.inspect(f);
                act.ui(() -> showInfo(f, i));
            } catch (Throwable e) {
                act.ui(() -> fail(e));
            }
        }).start();
    }

    private void showInfo(File f, ApkInspector.Info i) {
        apk = f;
        info = i;
        bar.setIndeterminate(false);
        setBusy(false);
        StringBuilder sb = new StringBuilder();
        sb.append("Тип: ").append(i.engineTitle).append('\n');
        sb.append("Файлов внутри: ").append(i.entries).append('\n');
        if (i.convertible) {
            sb.append("Игра: ").append(i.loveEntry != null ? i.loveEntry : "assets/ (исходники Lua)").append('\n');
            sb.append("Иконка: ").append(i.iconEntry != null ? "найдена" : "не найдена (будет иконка движка)")
                    .append('\n');
        }
        sb.append('\n').append(i.explanation);
        summary.setText(sb.toString());
        status.setText(i.convertible ? "Готово к сборке." : "Конвертация невозможна.");
        int vis = i.convertible ? View.VISIBLE : View.GONE;
        nameEt.setVisibility(vis);
        authorEt.setVisibility(vis);
        versionEt.setVisibility(vis);
        if (i.convertible) {
            nameEt.setText(apkName);
            authorEt.setText("Unknown");
            versionEt.setText("1.0.0");
        }
        buildBtn.setEnabled(i.convertible);
    }

    private void askSave() {
        if (info == null || !info.convertible || busy) return;
        String base = nameEt.getText().toString().trim();
        if (base.isEmpty()) base = "game";
        act.createFile(REQ_SAVE, base.replaceAll("[^A-Za-z0-9._-]", "_") + ".nro");
    }

    private void onSavePicked(Uri out) {
        final ApkInspector.Info i = info;
        final File apkFile = apk;
        final String name = nameEt.getText().toString().trim();
        final String author = authorEt.getText().toString().trim();
        final String version = versionEt.getText().toString().trim();
        setBusy(true);
        bar.setIndeterminate(true);
        status.setText("Достаю игру из APK…");
        new Thread(() -> {
            File love = new File(act.getCacheDir(), "apk-game.love");
            try {
                ApkInspector.extractGame(apkFile, i, love);
                byte[] icon = null;
                if (i.iconEntry != null) {
                    try {
                        icon = EngineRuntime.iconJpeg(ApkInspector.readEntry(apkFile, i.iconEntry));
                    } catch (RuntimeException ignored) {
                        icon = null; // не вышло прочитать иконку — останется иконка движка
                    }
                }
                byte[] nacp = NroBuilder.nacp(name.isEmpty() ? "Game" : name,
                        author.isEmpty() ? "Unknown" : author,
                        version.isEmpty() ? "1.0.0" : version);
                act.ui(() -> { bar.setIndeterminate(false); status.setText("Записываю файл…"); });
                final long[] last = {0};
                final long size = EngineRuntime.writeNro(act, out, nacp, icon, love, (done, total) -> {
                    long now = System.currentTimeMillis();
                    if (now - last[0] > 200 || done == total) {
                        last[0] = now;
                        act.ui(() -> bar.setProgress((int) (done * 1000 / Math.max(1, total))));
                    }
                });
                act.ui(() -> {
                    setBusy(false);
                    status.setText(String.format(Locale.US,
                            "Готово! .nro сохранён (около %.1f МБ). Скопируйте его на SD-карту "
                                    + "Switch в папку /switch/ и запустите из hbmenu.",
                            size / 1048576.0));
                });
            } catch (Throwable e) {
                act.ui(() -> fail(e));
            } finally {
                love.delete();
            }
        }).start();
    }
}
