package com.nromaker;

import android.content.Intent;
import android.net.Uri;
import android.text.InputType;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.util.Locale;

/** Экран 1: zip с игрой на Lua (или с готовым ELF) → .nro. */
final class NroScreen extends Screen {

    private static final int REQ_ZIP = 1, REQ_ICON = 2, REQ_SAVE = 3;

    static final String PROMPT =
            "Напиши простую, но законченную игру на Lua для LÖVE (версия 11.5). Она будет запускаться "
            + "на Nintendo Switch через LÖVE Potion.\n\n"
            + "Правила:\n"
            + "1. Результат — файлы: main.lua (обязательно, в корне), conf.lua (по желанию) и meta.json "
            + "вида {\"name\":\"Название\",\"author\":\"Автор\",\"version\":\"1.0.0\"}. Без внешних библиотек, "
            + "без картинок и звуков: всё рисуй фигурами через love.graphics.\n"
            + "2. Управление только геймпадом: движение — левый стик и крестовина "
            + "(joystick:getGamepadAxis(\"leftx\"/\"lefty\") и joystick:isGamepadDown(\"dpleft\"/\"dpright\"/"
            + "\"dpup\"/\"dpdown\")), действия — love.gamepadpressed(joystick, button) с кнопками "
            + "\"a\", \"b\", \"x\", \"y\". Выход из игры — кнопка \"start\" (love.event.quit()). "
            + "Джойстик бери через love.joystick.getJoysticks()[1] и обновляй в love.joystickadded.\n"
            + "3. Размер экрана бери из love.graphics.getDimensions(), love.window.setMode не вызывай.\n"
            + "4. Не используй сеть, потоки (love.thread), os.execute, io.popen, видео, а также "
            + "клавиатуру и мышь как единственный способ управления.\n"
            + "5. Весь текст на экране пиши по-английски (шрифт по умолчанию не содержит кириллицу).\n"
            + "6. Верни каждый файл отдельным блоком кода, над блоком — имя файла.\n\n"
            + "Игра: <опишите здесь, какую игру хотите>";

    private final File workDir;
    private GameZip.Found found;
    private Uri iconOverride;
    private volatile boolean busy;

    private TextView summary, status, iconLabel;
    private EditText nameEt, authorEt, versionEt;
    private CheckBox packLoose;
    private ProgressBar bar;
    private Button zipBtn, iconBtn, buildBtn;

    NroScreen(MainActivity act) {
        super(act);
        workDir = new File(act.getCacheDir(), "work");
    }

    @Override String title() { return "Сборка NRO"; }

    @Override boolean isBusy() { return busy; }

    @Override
    void fill(LinearLayout col) {
        Ui.add(col, Ui.text(act,
                "Как собрать NRO для Nintendo Switch:\n\n"
                + "1. Подготовьте zip с игрой на Lua (LÖVE): в корне файл main.lua и ресурсы игры. "
                + "По желанию добавьте icon.png (иконка) и meta.json: "
                + "{\"name\":\"Игра\",\"author\":\"Я\",\"version\":\"1.0\"}.\n"
                + "2. Нажмите «Выбрать ZIP с игрой». ELF не нужен — игра запускается на встроенном "
                + "движке LÖVE Potion. (Если в zip лежит готовый .elf или .nro, сборка пойдёт из него.)\n"
                + "3. Проверьте название, автора и версию, нажмите «Собрать и сохранить .nro».\n"
                + "4. Скопируйте файл на SD-карту Switch в папку /switch/ и запустите из hbmenu.",
                14), 8);

        Ui.add(col, Ui.button(act, "Скопировать промпт для нейросети", v -> {
            act.copyText("Промпт для игры", PROMPT);
            act.toast("Промпт скопирован: вставьте его в нейросеть");
        }), 8);

        zipBtn = Ui.button(act, "1. Выбрать ZIP с игрой", v -> {
            if (!busy) act.pick(REQ_ZIP, "*/*");
        });
        Ui.add(col, zipBtn, 12);

        summary = Ui.text(act, "Архив не выбран", 14);
        Ui.add(col, summary, 4);

        nameEt = field("Название");
        authorEt = field("Автор");
        versionEt = field("Версия");
        Ui.add(col, nameEt, 4);
        Ui.add(col, authorEt, 0);
        Ui.add(col, versionEt, 0);

        packLoose = new CheckBox(act);
        packLoose.setText("Если папки romfs нет — положить остальные файлы рядом с ELF в romfs");
        packLoose.setChecked(true);
        Ui.add(col, packLoose, 4);

        iconBtn = Ui.button(act, "Заменить иконку (необязательно)", v -> {
            if (!busy) act.pick(REQ_ICON, "image/*");
        });
        Ui.add(col, iconBtn, 4);
        iconLabel = Ui.text(act, "", 13);
        Ui.add(col, iconLabel, 0);

        buildBtn = Ui.button(act, "2. Собрать и сохранить .nro", v -> askSaveLocation());
        buildBtn.setEnabled(false);
        Ui.add(col, buildBtn, 8);

        bar = new ProgressBar(act, null, android.R.attr.progressBarStyleHorizontal);
        bar.setMax(1000);
        bar.setVisibility(View.GONE);
        Ui.add(col, bar, 4);

        status = Ui.text(act, "", 14);
        Ui.add(col, status, 8);
    }

    private EditText field(String hint) {
        EditText e = new EditText(act);
        e.setHint(hint);
        e.setInputType(InputType.TYPE_CLASS_TEXT);
        return e;
    }

    private void setBusy(boolean b) {
        busy = b;
        zipBtn.setEnabled(!b);
        iconBtn.setEnabled(!b);
        buildBtn.setEnabled(!b && found != null && (found.binary != null || found.engineMode));
        bar.setVisibility(b ? View.VISIBLE : View.GONE);
    }

    private void fail(Throwable e) {
        bar.setIndeterminate(false);
        setBusy(false);
        String m = e.getMessage();
        status.setText("Ошибка: " + (m == null ? e.getClass().getSimpleName() : m));
    }

    @Override
    void onResult(int req, int res, Intent data) {
        if (res != android.app.Activity.RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        if (req == REQ_ZIP) onZipPicked(uri);
        else if (req == REQ_ICON) {
            iconOverride = uri;
            iconLabel.setText("Иконка: " + act.displayName(uri));
        } else if (req == REQ_SAVE) onSavePicked(uri);
    }

    private void onZipPicked(Uri uri) {
        final String zipName = act.displayName(uri);
        found = null;
        iconOverride = null;
        iconLabel.setText("");
        setBusy(true);
        status.setText("Распаковываю…");
        bar.setIndeterminate(true);
        new Thread(() -> {
            try {
                MainActivity.deleteRec(workDir);
                workDir.mkdirs();
                try (InputStream in = act.getContentResolver().openInputStream(uri)) {
                    if (in == null) throw new IOException("Не удалось открыть выбранный файл");
                    GameZip.extract(in, workDir, n -> {
                        if (n % 20 == 0) act.ui(() -> status.setText("Распаковано файлов: " + n));
                    });
                }
                final GameZip.Found f = GameZip.scan(workDir, zipName);
                act.ui(() -> showFound(f));
            } catch (Throwable e) {
                act.ui(() -> fail(e));
            }
        }).start();
    }

    private void showFound(GameZip.Found f) {
        found = f;
        bar.setIndeterminate(false);
        setBusy(false);
        nameEt.setText(f.name);
        authorEt.setText(f.author);
        versionEt.setText(f.version);

        StringBuilder sb = new StringBuilder();
        sb.append("Файлов в архиве: ").append(f.totalFiles).append('\n');
        boolean ok = f.binary != null || f.engineMode;
        if (f.binary != null) {
            sb.append(f.binaryIsNro ? "NRO: " : "ELF: ").append(f.binary.getName()).append('\n');
        } else if (f.engineMode) {
            sb.append("Игра LÖVE (Lua): main.lua найден, движок встроен — ELF не нужен.\n");
        } else {
            sb.append("Не найден ни main.lua, ни .elf/.nro — собрать нечего.\n");
        }
        sb.append("Иконка: ").append(f.icon != null ? f.icon.getName() : "не найдена (будет иконка движка)")
                .append('\n');
        if (!f.engineMode) {
            if (f.romfsDir != null) sb.append("RomFS: папка romfs");
            else if (f.looseFiles > 0) sb.append("RomFS: папки romfs нет, рядом с ELF файлов: ").append(f.looseFiles);
            else sb.append("RomFS: нет");
        }
        summary.setText(sb.toString());
        status.setText(ok ? "Готово к сборке." : "");
        buildBtn.setEnabled(ok);
    }

    private void askSaveLocation() {
        if (found == null || (found.binary == null && !found.engineMode) || busy) return;
        String base = nameEt.getText().toString().trim();
        if (base.isEmpty()) base = "game";
        act.createFile(REQ_SAVE, base.replaceAll("[^A-Za-z0-9._-]", "_") + ".nro");
    }

    private byte[] iconBytes(File file, Uri uri) throws IOException {
        if (uri != null) {
            try (InputStream in = act.getContentResolver().openInputStream(uri)) {
                if (in == null) throw new IOException("Не удалось открыть иконку");
                java.io.ByteArrayOutputStream bos = new java.io.ByteArrayOutputStream();
                byte[] buf = new byte[1 << 14];
                int n;
                while ((n = in.read(buf)) > 0) bos.write(buf, 0, n);
                return bos.toByteArray();
            }
        }
        return Files.readAllBytes(file.toPath());
    }

    private void onSavePicked(Uri out) {
        final GameZip.Found f = found;
        final String name = nameEt.getText().toString().trim();
        final String author = authorEt.getText().toString().trim();
        final String version = versionEt.getText().toString().trim();
        final boolean loose = packLoose.isChecked();
        final Uri iconUri = iconOverride;
        setBusy(true);
        bar.setIndeterminate(true);
        status.setText("Собираю…");
        new Thread(() -> {
            try {
                byte[] nacp = NroBuilder.nacp(name.isEmpty() ? "Game" : name,
                        author.isEmpty() ? "Unknown" : author,
                        version.isEmpty() ? "1.0.0" : version);
                byte[] icon = null;
                if (iconUri != null || f.icon != null) icon = EngineRuntime.iconJpeg(iconBytes(f.icon, iconUri));

                final long[] last = {0};
                RomFs.Progress progress = (done, total) -> {
                    long now = System.currentTimeMillis();
                    if (now - last[0] > 200 || done == total) {
                        last[0] = now;
                        act.ui(() -> bar.setProgress((int) (done * 1000 / Math.max(1, total))));
                    }
                };

                final long size;
                if (f.engineMode) {
                    act.ui(() -> status.setText("Упаковываю игру…"));
                    File love = new File(act.getCacheDir(), "game.love");
                    LoveArchive.pack(f.luaRoot, love);
                    act.ui(() -> { bar.setIndeterminate(false); status.setText("Записываю файл…"); });
                    size = EngineRuntime.writeNro(act, out, nacp, icon, love, progress);
                    love.delete();
                } else {
                    byte[] bin = Files.readAllBytes(f.binary.toPath());
                    byte[] nro = f.binaryIsNro ? bin : NroBuilder.elfToNro(bin);
                    RomFs romfs = null;
                    if (f.romfsDir != null) romfs = RomFs.build(f.romfsDir, null);
                    else if (loose && f.looseRoot != null) romfs = RomFs.build(f.looseRoot, f.looseExclude);
                    if (romfs != null && romfs.fileCount() == 0) romfs = null;
                    act.ui(() -> { bar.setIndeterminate(false); status.setText("Записываю файл…"); });
                    OutputStream raw = act.getContentResolver().openOutputStream(out, "wt");
                    if (raw == null) throw new IOException("Не удалось открыть файл для записи");
                    try (OutputStream os = new BufferedOutputStream(raw, 1 << 16)) {
                        NroBuilder.write(nro, nacp, icon, romfs, os, progress);
                    }
                    size = nro.length + (romfs == null ? 0 : romfs.size());
                }
                act.ui(() -> {
                    setBusy(false);
                    status.setText(String.format(Locale.US,
                            "Готово! .nro сохранён (около %.1f МБ). Скопируйте его на SD-карту "
                                    + "Switch в папку /switch/ и запустите из hbmenu.",
                            size / 1048576.0));
                });
            } catch (Throwable e) {
                act.ui(() -> fail(e));
            }
        }).start();
    }
}
