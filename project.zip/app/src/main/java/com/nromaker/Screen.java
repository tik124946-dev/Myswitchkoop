package com.nromaker;

import android.content.Intent;
import android.view.View;
import android.widget.LinearLayout;

/** Один экран приложения. Главное меню переключает экраны через MainActivity. */
abstract class Screen {

    protected final MainActivity act;

    Screen(MainActivity act) { this.act = act; }

    abstract String title();

    abstract void fill(LinearLayout col);

    void onResult(int req, int res, Intent data) { }

    boolean isBusy() { return false; }

    View build() {
        LinearLayout col = Ui.column(act, 16);
        Ui.add(col, Ui.button(act, "← Назад", v -> act.back()), 0);
        Ui.add(col, Ui.text(act, title(), 22), 8);
        fill(col);
        return col;
    }
}
