package com.nromaker;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Enumeration;
import java.util.List;
import java.util.Locale;
import java.util.regex.Pattern;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipOutputStream;

/**
 * Разбор APK. Честно: перенести на Switch можно только игры на LÖVE (Lua),
 * потому что в них игра лежит внутри APK в виде .love / исходников Lua.
 * Всё остальное (Unity, Godot, Unreal, чистый Java) на Switch не запустить.
 */
public final class ApkInspector {

    public static final class Info {
        public String engine = "unknown";
        public String engineTitle = "Неизвестный движок";
        public String loveEntry;        // например assets/game.love
        public boolean looseLua;        // assets/main.lua — игра лежит «россыпью»
        public String iconEntry;
        public boolean convertible;
        public String explanation = "";
        public int entries;

        public boolean hasGame() { return loveEntry != null || looseLua; }
    }

    private ApkInspector() {}

    private static boolean any(List<String> names, String regex) {
        Pattern p = Pattern.compile(regex, Pattern.CASE_INSENSITIVE);
        for (String n : names) if (p.matcher(n).find()) return true;
        return false;
    }

    public static Info inspect(File apk) throws IOException {
        Info info = new Info();
        List<String> names = new ArrayList<>();
        long bestIcon = -1;
        boolean bestIconRound = true;
        Pattern iconRe = Pattern.compile("^res/[^/]+/(ic_launcher|icon|app_icon)(_round)?\\.(png|webp|jpg)$",
                Pattern.CASE_INSENSITIVE);
        try (ZipFile z = new ZipFile(apk)) {
            Enumeration<? extends ZipEntry> en = z.entries();
            while (en.hasMoreElements()) {
                ZipEntry e = en.nextElement();
                if (e.isDirectory()) continue;
                String n = e.getName();
                names.add(n);
                java.util.regex.Matcher m = iconRe.matcher(n);
                if (m.matches()) {
                    boolean round = m.group(2) != null;
                    long size = e.getSize();
                    if (bestIcon < 0 || (bestIconRound && !round) || (round == bestIconRound && size > bestIcon)) {
                        // обычная иконка важнее круглой, а среди равных берём самую большую
                        bestIcon = size;
                        bestIconRound = round;
                        info.iconEntry = n;
                    }
                }
            }
        }
        info.entries = names.size();

        if (!names.contains("AndroidManifest.xml")) {
            if (any(names, "\\.apk$")) {
                info.explanation = "Это набор из нескольких APK (XAPK/APKS). Распакуйте его и выберите основной файл .apk.";
            } else {
                info.explanation = "Это не APK: внутри нет AndroidManifest.xml.";
            }
            info.engine = "invalid";
            info.engineTitle = "Не APK";
            return info;
        }

        String love = null;
        for (String n : names) {
            if (n.matches("(?i)assets/[^/]+\\.love")) {
                if (love == null || n.equalsIgnoreCase("assets/game.love")) love = n;
            }
        }
        info.loveEntry = love;
        info.looseLua = names.contains("assets/main.lua");

        boolean liblove = any(names, "^lib/[^/]+/liblove\\.so$");
        if (info.hasGame() || liblove) {
            info.engine = "love";
            info.engineTitle = "LÖVE (Lua)";
            if (info.hasGame()) {
                info.convertible = true;
                info.explanation = "Игра на LÖVE найдена внутри APK. Её можно собрать в NRO на движке LÖVE Potion. "
                        + "Учтите: мобильные игры часто рассчитаны на касание экрана, а не на геймпад.";
            } else {
                info.explanation = "Это движок LÖVE, но самой игры внутри APK нет (она хранится отдельно). Конвертировать нечего.";
            }
            return info;
        }

        if (any(names, "^lib/[^/]+/libunity\\.so$") || any(names, "^assets/bin/Data/")) {
            info.engine = "unity";
            info.engineTitle = "Unity";
            info.explanation = "Игра на Unity: код и ресурсы скомпилированы под Android и закрыты. "
                    + "Запустить их на Switch нельзя, готового конвертера не существует. "
                    + "Порт на Switch делается только из исходного проекта и с лицензией Nintendo.";
        } else if (any(names, "^lib/[^/]+/libgodot_android\\.so$") || any(names, "^assets/[^/]+\\.pck$")) {
            info.engine = "godot";
            info.engineTitle = "Godot";
            info.explanation = "Игра на Godot. Версии Godot для Switch в свободном доступе нет, "
                    + "поэтому конвертировать такую игру нельзя.";
        } else if (any(names, "^lib/[^/]+/lib(UE4|Unreal)\\.so$")) {
            info.engine = "unreal";
            info.engineTitle = "Unreal Engine";
            info.explanation = "Игра на Unreal Engine. Перенос на Switch невозможен без исходного проекта и лицензии Nintendo.";
        } else if (any(names, "^lib/[^/]+/libflutter\\.so$") || any(names, "^assets/flutter_assets/")) {
            info.engine = "flutter";
            info.engineTitle = "Flutter";
            info.explanation = "Приложение на Flutter. Для Switch такого движка нет.";
        } else if (names.contains("assets/index.android.bundle")) {
            info.engine = "reactnative";
            info.engineTitle = "React Native";
            info.explanation = "Приложение на React Native. На Switch оно работать не может.";
        } else if (any(names, "^lib/[^/]+/libmonodroid\\.so$")) {
            info.engine = "xamarin";
            info.engineTitle = "Xamarin / .NET для Android";
            info.explanation = "Приложение на Xamarin. На Switch оно работать не может.";
        } else if (any(names, "^lib/[^/]+/libcocos")) {
            info.engine = "cocos";
            info.engineTitle = "Cocos2d-x";
            info.explanation = "Игра на Cocos2d-x: код скомпилирован под Android, перенести на Switch нельзя.";
        } else {
            info.engine = "android";
            info.engineTitle = "Обычное Android-приложение";
            info.explanation = "Обычное Android-приложение (код для Android). На Switch нет Android и Java, "
                    + "поэтому запустить или конвертировать его нельзя.";
        }
        return info;
    }

    public static byte[] readEntry(File apk, String entry) throws IOException {
        try (ZipFile z = new ZipFile(apk)) {
            ZipEntry e = z.getEntry(entry);
            if (e == null) throw new IOException("В APK нет файла " + entry);
            try (InputStream in = z.getInputStream(e)) {
                java.io.ByteArrayOutputStream bos = new java.io.ByteArrayOutputStream();
                byte[] buf = new byte[1 << 14];
                int n;
                while ((n = in.read(buf)) > 0) bos.write(buf, 0, n);
                return bos.toByteArray();
            }
        }
    }

    /** Достаёт игру из APK в файл .love (zip с main.lua в корне). */
    public static void extractGame(File apk, Info info, File outLove) throws IOException {
        if (!info.hasGame()) throw new IOException("В этом APK нет игры LÖVE");
        byte[] buf = new byte[1 << 16];
        try (ZipFile z = new ZipFile(apk)) {
            if (info.loveEntry != null) {
                ZipEntry e = z.getEntry(info.loveEntry);
                try (InputStream in = z.getInputStream(e);
                     OutputStream out = new BufferedOutputStream(new FileOutputStream(outLove), 1 << 16)) {
                    int n;
                    while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                }
                return;
            }
            // игра лежит россыпью в assets/ — собираем .love сами
            List<String> list = new ArrayList<>();
            Enumeration<? extends ZipEntry> en = z.entries();
            while (en.hasMoreElements()) {
                ZipEntry e = en.nextElement();
                String n = e.getName();
                if (!e.isDirectory() && n.startsWith("assets/") && !n.contains("..")) list.add(n);
            }
            Collections.sort(list);
            try (ZipOutputStream out = new ZipOutputStream(new BufferedOutputStream(new FileOutputStream(outLove), 1 << 16))) {
                for (String n : list) {
                    String rel = n.substring("assets/".length());
                    if (rel.isEmpty()) continue;
                    out.putNextEntry(new ZipEntry(rel));
                    try (InputStream in = z.getInputStream(z.getEntry(n))) {
                        int c;
                        while ((c = in.read(buf)) > 0) out.write(buf, 0, c);
                    }
                    out.closeEntry();
                }
            }
        }
    }

    public static String lowerName(String s) { return s == null ? "" : s.toLowerCase(Locale.ROOT); }
}
