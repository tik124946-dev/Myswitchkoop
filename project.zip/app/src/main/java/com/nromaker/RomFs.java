package com.nromaker;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

/** Сборка образа RomFS (формат Switch) из папки на диске. Данные файлов пишутся потоково. */
public final class RomFs {

    public interface Progress { void onProgress(long done, long total); }

    private static final int NONE = -1;
    private static final int DATA_ALIGN = 0x10;
    private static final int PART_ALIGN = 0x200;

    private static final class Dir {
        final String name;
        final Dir parent;
        final TreeMap<String, Dir> dirs = new TreeMap<>();
        final TreeMap<String, Ent> files = new TreeMap<>();
        int off;
        Dir(String name, Dir parent) { this.name = name; this.parent = parent; }
    }

    private static final class Ent {
        final String name;
        final File file;
        final Dir parent;
        int off;
        long dataOff;
        long size;
        Ent(String name, File file, Dir parent) { this.name = name; this.file = file; this.parent = parent; }
    }

    private final Dir root = new Dir("", null);
    private final List<Dir> dirList = new ArrayList<>();
    private final List<Ent> fileList = new ArrayList<>();
    private byte[] head;
    private long dataSize;
    private long total;

    private RomFs() {}

    public long size() { return total; }
    public int fileCount() { return fileList.size(); }

    /** Собирает дерево из папки root, пропуская файлы из exclude (может быть null). */
    public static RomFs build(File rootDir, Set<File> exclude) throws IOException {
        RomFs r = new RomFs();
        r.scan(rootDir, r.root, exclude);
        r.layout();
        return r;
    }

    private void scan(File dir, Dir node, Set<File> exclude) throws IOException {
        File[] list = dir.listFiles();
        if (list == null) throw new IOException("Не удалось прочитать папку " + dir);
        for (File f : list) {
            if (f.isDirectory()) {
                Dir sub = new Dir(f.getName(), node);
                node.dirs.put(f.getName(), sub);
                scan(f, sub, exclude);
            } else if (f.isFile()) {
                if (exclude != null && exclude.contains(f.getAbsoluteFile())) continue;
                Ent e = new Ent(f.getName(), f, node);
                e.size = f.length();
                node.files.put(f.getName(), e);
            }
        }
    }

    private static int align4(int v) { return (v + 3) & ~3; }
    private static long alignL(long v, long a) { return (v + a - 1) / a * a; }

    private static int hashCount(int entries) {
        if (entries < 3) return 3;
        if (entries < 19) return entries | 1;
        int c = entries;
        while (c % 2 == 0 || c % 3 == 0 || c % 5 == 0 || c % 7 == 0 || c % 11 == 0
                || c % 13 == 0 || c % 17 == 0) c++;
        return c;
    }

    private static int hash(int parent, byte[] name) {
        int h = parent ^ 123456789;
        for (byte b : name) {
            h = (h >>> 5) | (h << 27);
            h ^= (b & 0xFF);
        }
        return h;
    }

    private static byte[] utf8(String s) { return s.getBytes(StandardCharsets.UTF_8); }

    private void collect(Dir d) {
        dirList.add(d);
        for (Dir s : d.dirs.values()) collect(s);
    }

    private void layout() {
        collect(root);
        for (Dir d : dirList) fileList.addAll(d.files.values());

        int dirMetaSize = 0;
        for (Dir d : dirList) {
            d.off = dirMetaSize;
            dirMetaSize += 0x18 + align4(utf8(d.name).length);
        }
        int fileMetaSize = 0;
        for (Ent e : fileList) {
            e.off = fileMetaSize;
            fileMetaSize += 0x20 + align4(utf8(e.name).length);
        }
        long cursor = 0;
        for (Ent e : fileList) {
            cursor = alignL(cursor, DATA_ALIGN);
            e.dataOff = cursor;
            cursor += e.size;
        }
        dataSize = cursor;

        int dirHashCnt = hashCount(dirList.size());
        int fileHashCnt = hashCount(fileList.size());
        int dirHashOff = 0x50;
        int dirMetaOff = dirHashOff + dirHashCnt * 4;
        int fileHashOff = dirMetaOff + dirMetaSize;
        int fileMetaOff = fileHashOff + fileHashCnt * 4;
        int headEnd = fileMetaOff + fileMetaSize;
        int dataStart = (int) alignL(headEnd, PART_ALIGN);

        ByteBuffer b = ByteBuffer.allocate(dataStart).order(ByteOrder.LITTLE_ENDIAN);
        b.putLong(0x50);
        b.putLong(dirHashOff);   b.putLong(dirHashCnt * 4L);
        b.putLong(dirMetaOff);   b.putLong(dirMetaSize);
        b.putLong(fileHashOff);  b.putLong(fileHashCnt * 4L);
        b.putLong(fileMetaOff);  b.putLong(fileMetaSize);
        b.putLong(dataStart);

        int[] dirTable = new int[dirHashCnt];
        int[] fileTable = new int[fileHashCnt];
        java.util.Arrays.fill(dirTable, NONE);
        java.util.Arrays.fill(fileTable, NONE);

        for (Dir d : dirList) {
            byte[] nm = utf8(d.name);
            int parentOff = d.parent == null ? 0 : d.parent.off;
            int idx = (int) ((hash(parentOff, nm) & 0xFFFFFFFFL) % dirHashCnt);
            int next = dirTable[idx];
            dirTable[idx] = d.off;

            int sibling = NONE;
            if (d.parent != null) {
                Map.Entry<String, Dir> s = d.parent.dirs.higherEntry(d.name);
                if (s != null) sibling = s.getValue().off;
            }
            int child = d.dirs.isEmpty() ? NONE : d.dirs.firstEntry().getValue().off;
            int file = d.files.isEmpty() ? NONE : d.files.firstEntry().getValue().off;

            b.position(dirMetaOff + d.off);
            b.putInt(parentOff);
            b.putInt(sibling);
            b.putInt(child);
            b.putInt(file);
            b.putInt(next);
            b.putInt(nm.length);
            b.put(nm);
        }

        for (Ent e : fileList) {
            byte[] nm = utf8(e.name);
            int idx = (int) ((hash(e.parent.off, nm) & 0xFFFFFFFFL) % fileHashCnt);
            int next = fileTable[idx];
            fileTable[idx] = e.off;

            int sibling = NONE;
            Map.Entry<String, Ent> s = e.parent.files.higherEntry(e.name);
            if (s != null) sibling = s.getValue().off;

            b.position(fileMetaOff + e.off);
            b.putInt(e.parent.off);
            b.putInt(sibling);
            b.putLong(e.dataOff);
            b.putLong(e.size);
            b.putInt(next);
            b.putInt(nm.length);
            b.put(nm);
        }

        b.position(dirHashOff);
        for (int v : dirTable) b.putInt(v);
        b.position(fileHashOff);
        for (int v : fileTable) b.putInt(v);

        head = b.array();
        total = dataStart + dataSize;
    }

    /** Пишет образ в поток. Всегда записывает ровно size() байт. */
    public void writeTo(OutputStream out, Progress progress) throws IOException {
        out.write(head);
        long pos = 0;
        long done = head.length;
        byte[] buf = new byte[1 << 16];
        for (Ent e : fileList) {
            while (pos < e.dataOff) {
                int n = (int) Math.min(buf.length, e.dataOff - pos);
                out.write(new byte[n], 0, n);
                pos += n;
                done += n;
            }
            long left = e.size;
            try (InputStream in = new FileInputStream(e.file)) {
                while (left > 0) {
                    int n = in.read(buf, 0, (int) Math.min(buf.length, left));
                    if (n < 0) throw new IOException("Файл изменился во время сборки: " + e.name);
                    out.write(buf, 0, n);
                    left -= n;
                    pos += n;
                    done += n;
                    if (progress != null) progress.onProgress(done, total);
                }
            }
        }
        if (progress != null) progress.onProgress(total, total);
    }
}
