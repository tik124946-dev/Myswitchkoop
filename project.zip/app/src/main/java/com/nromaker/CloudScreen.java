package com.nromaker;

import android.content.Intent;
import android.graphics.Typeface;
import android.net.Uri;
import android.text.InputType;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.Locale;

/** Экраны 2 и 4: сборка APK / EXE в облаке GitHub прямо с телефона. */
final class CloudScreen extends Screen {

    private static final int REQ_ZIP = 1, REQ_SAVE = 2;

    private final String title, intro, workflowAsset, workflowFile, ext;

    private Uri zipUri;
    private String zipName;
    private File saveFile;
    private volatile boolean busy;

    private EditText tokenEt, repoEt;
    private TextView zipLabel, status, logView;
    private ProgressBar bar;
    private Button zipBtn, buildBtn, saveBtn;

    private CloudScreen(MainActivity act, String title, String intro, String workflowAsset,
                        String workflowFile, String ext) {
        super(act);
        this.title = title;
        this.intro = intro;
        this.workflowAsset = workflowAsset;
        this.workflowFile = workflowFile;
        this.ext = ext;
    }

    static CloudScreen apk(MainActivity act) {
        return new CloudScreen(act, "Сборка APK",
                "Собирает Android-проект в готовый .apk прямо с телефона — на серверах GitHub (бесплатно).\n\n"
                + "Что нужно:\n"
                + "1. Аккаунт на github.com.\n"
                + "2. Токен доступа: GitHub → Settings → Developer settings → Personal access tokens → "
                + "Tokens (classic) → Generate new token (classic). Отметьте галочки repo и workflow, "
                + "нажмите Generate и вставьте токен ниже. Токен хранится только на вашем телефоне, "
                + "никому его не показывайте.\n"
                + "3. Zip с проектом Android Studio (внутри settings.gradle или settings.gradle.kts), размером до 20 МБ — папки build и .gradle лучше убрать.\n\n"
                + "Что произойдёт: приложение создаст в вашем GitHub приватный репозиторий, загрузит туда "
                + "проект, запустит сборку, дождётся её (обычно 5–15 минут) и даст сохранить готовый .apk. "
                + "Не закрывайте приложение, пока идёт сборка.",
                "workflows/android.yml", "android.yml", ".apk");
    }

    static CloudScreen exe(MainActivity act) {
        return new CloudScreen(act, "Сборка EXE",
                "Собирает проект в готовый .exe для Windows прямо с телефона — на серверах GitHub (бесплатно).\n\n"
                + "Что нужно:\n"
                + "1. Аккаунт на github.com.\n"
                + "2. Токен доступа: GitHub → Settings → Developer settings → Personal access tokens → "
                + "Tokens (classic) → Generate new token (classic). Отметьте галочки repo и workflow, "
                + "нажмите Generate и вставьте токен ниже. Токен хранится только на вашем телефоне, "
                + "никому его не показывайте.\n"
                + "3. Zip с проектом размером до 20 МБ. Поддерживаются:\n"
                + "• Python — main.py (и requirements.txt, если нужен): соберётся через PyInstaller;\n"
                + "• .NET — файлы .sln или .csproj;\n"
                + "• CMake — файл CMakeLists.txt;\n"
                + "• C / C++ — файлы .c или .cpp в корне проекта.\n\n"
                + "Что произойдёт: приложение создаст в вашем GitHub приватный репозиторий, загрузит туда "
                + "проект, запустит сборку, дождётся её (обычно 3–10 минут) и даст сохранить готовый .exe. "
                + "Не закрывайте приложение, пока идёт сборка.",
                "workflows/windows.yml", "windows.yml", ".exe");
    }

    @Override String title() { return title; }

    @Override boolean isBusy() { return busy; }

    @Override
    void fill(LinearLayout col) {
        Ui.add(col, Ui.text(act, intro, 14), 8);

        tokenEt = new EditText(act);
        tokenEt.setHint("Токен GitHub");
        tokenEt.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        tokenEt.setText(act.prefs().getString("gh_token", ""));
        Ui.add(col, tokenEt, 12);

        repoEt = new EditText(act);
        repoEt.setHint("Имя репозитория для сборок");
        repoEt.setInputType(InputType.TYPE_CLASS_TEXT);
        repoEt.setText(act.prefs().getString("gh_repo", "nro-maker-builds"));
        Ui.add(col, repoEt, 0);

        zipBtn = Ui.button(act, "1. Выбрать ZIP с проектом", v -> {
            if (!busy) act.pick(REQ_ZIP, "*/*");
        });
        Ui.add(col, zipBtn, 8);
        zipLabel = Ui.text(act, "Проект не выбран", 13);
        Ui.add(col, zipLabel, 0);

        buildBtn = Ui.button(act, "2. Собрать в облаке", v -> startBuild());
        Ui.add(col, buildBtn, 8);

        bar = new ProgressBar(act, null, android.R.attr.progressBarStyleHorizontal);
        bar.setIndeterminate(true);
        bar.setVisibility(View.GONE);
        Ui.add(col, bar, 4);

        status = Ui.text(act, "", 14);
        Ui.add(col, status, 8);

        logView = Ui.text(act, "", 11);
        logView.setTypeface(Typeface.MONOSPACE);
        logView.setTextIsSelectable(true);
        Ui.add(col, logView, 4);

        saveBtn = Ui.button(act, "3. Сохранить результат", v -> {
            if (saveFile != null) act.createFile(REQ_SAVE, saveFile.getName());
        });
        saveBtn.setVisibility(View.GONE);
        Ui.add(col, saveBtn, 8);
    }

    private void setBusy(boolean b) {
        busy = b;
        zipBtn.setEnabled(!b);
        buildBtn.setEnabled(!b);
        tokenEt.setEnabled(!b);
        repoEt.setEnabled(!b);
        bar.setVisibility(b ? View.VISIBLE : View.GONE);
    }

    private void fail(Throwable e) {
        setBusy(false);
        String m = e.getMessage();
        status.setText("Ошибка: " + (m == null ? e.getClass().getSimpleName() : m));
    }

    @Override
    void onResult(int req, int res, Intent data) {
        if (res != android.app.Activity.RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        if (req == REQ_ZIP) {
            zipUri = uri;
            zipName = act.displayName(uri);
            zipLabel.setText("Выбрано: " + (zipName == null ? uri.getLastPathSegment() : zipName));
        } else if (req == REQ_SAVE && saveFile != null) {
            final File src = saveFile;
            new Thread(() -> {
                try {
                    act.copyToUri(src, uri);
                    act.ui(() -> status.setText("Сохранено: " + src.getName()));
                } catch (Throwable e) {
                    act.ui(() -> fail(e));
                }
            }).start();
        }
    }

    private String readAsset(String name) throws IOException {
        try (InputStream in = act.getAssets().open(name)) {
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            byte[] buf = new byte[1 << 12];
            int n;
            while ((n = in.read(buf)) > 0) bos.write(buf, 0, n);
            return new String(bos.toByteArray(), StandardCharsets.UTF_8);
        }
    }

    private void startBuild() {
        final String token = tokenEt.getText().toString().trim();
        final String repo = repoEt.getText().toString().trim();
        if (token.isEmpty()) { status.setText("Введите токен GitHub."); return; }
        if (zipUri == null) { status.setText("Сначала выберите zip с проектом."); return; }
        act.prefs().edit().putString("gh_token", token).putString("gh_repo", repo).apply();

        final Uri uri = zipUri;
        saveFile = null;
        saveBtn.setVisibility(View.GONE);
        logView.setText("");
        status.setText("Готовлю проект…");
        setBusy(true);

        new Thread(() -> {
            try {
                File root = new File(act.getCacheDir(), "cloud");
                MainActivity.deleteRec(root);
                root.mkdirs();
                File project = act.copyToCache(uri, "cloud/project.zip");
                String yaml = readAsset(workflowAsset);
                CloudBuild cb = new CloudBuild(new GithubClient("https://api.github.com", token),
                        msg -> act.ui(() -> status.setText(msg)), 8000, 45L * 60 * 1000);
                CloudBuild.Result r = cb.run(repo, project, yaml, workflowFile, new File(root, "result"));
                act.ui(() -> done(r));
            } catch (Throwable e) {
                act.ui(() -> fail(e));
            }
        }).start();
    }

    private void done(CloudBuild.Result r) {
        setBusy(false);
        if (!r.ok) {
            status.setText("Сборка не удалась. Ниже причина — по ней можно исправить проект.");
            logView.setText(r.failLog);
            return;
        }
        File pick = null;
        int count = 0;
        for (File f : r.files) {
            if (f.getName().toLowerCase(Locale.ROOT).endsWith(ext)) {
                pick = f;
                count++;
            }
        }
        saveFile = (count == 1) ? pick : r.zip;
        status.setText(String.format(Locale.US, "Готово! Результат: %s (%.1f МБ). Нажмите «Сохранить результат».",
                saveFile.getName(), saveFile.length() / 1048576.0));
        saveBtn.setVisibility(View.VISIBLE);
    }
}
