package com.nromaker;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

public class MainActivity extends Activity {

    static final String AUTHOR_HANDLE = "@NROSWITCH1";
    static final String TEA_PHONE = "79916265769";
    static final String TEA_BANK = "Озон Банк";

    private FrameLayout root;
    private Screen current;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        root = new FrameLayout(this);
        setContentView(root);
        showHome();
    }

    // ---------- помощники для экранов ----------

    void ui(Runnable r) { runOnUiThread(r); }

    void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }

    SharedPreferences prefs() { return getSharedPreferences("nromaker", MODE_PRIVATE); }

    void copyText(String label, String text) {
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        if (cm != null) cm.setPrimaryClip(ClipData.newPlainText(label, text));
    }

    @SuppressWarnings("deprecation")
    void pick(int req, String mime) {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType(mime);
        startActivityForResult(i, req);
    }

    @SuppressWarnings("deprecation")
    void createFile(int req, String name) {
        Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("application/octet-stream");
        i.putExtra(Intent.EXTRA_TITLE, name);
        startActivityForResult(i, req);
    }

    String displayName(Uri uri) {
        try (Cursor c = getContentResolver().query(uri, null, null, null, null)) {
            if (c != null && c.moveToFirst()) {
                int idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (idx >= 0) return c.getString(idx);
            }
        } catch (Exception ignored) { }
        return null;
    }

    /** Копирует выбранный пользователем файл в кэш приложения. */
    File copyToCache(Uri uri, String fileName) throws IOException {
        File f = new File(getCacheDir(), fileName);
        try (InputStream in = getContentResolver().openInputStream(uri)) {
            if (in == null) throw new IOException("Не удалось открыть выбранный файл");
            try (OutputStream out = new BufferedOutputStream(new FileOutputStream(f), 1 << 16)) {
                byte[] buf = new byte[1 << 16];
                int n;
                while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            }
        }
        return f;
    }

    /** Копирует файл из кэша по адресу, который выбрал пользователь. */
    void copyToUri(File src, Uri dest) throws IOException {
        OutputStream raw = getContentResolver().openOutputStream(dest, "wt");
        if (raw == null) throw new IOException("Не удалось открыть файл для записи");
        try (InputStream in = new java.io.FileInputStream(src);
             OutputStream out = new BufferedOutputStream(raw, 1 << 16)) {
            byte[] buf = new byte[1 << 16];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
        }
    }

    static void deleteRec(File f) {
        File[] list = f.listFiles();
        if (list != null) for (File c : list) deleteRec(c);
        f.delete();
    }

    // ---------- навигация ----------

    void showScreen(Screen s) {
        current = s;
        root.removeAllViews();
        ScrollView sv = new ScrollView(this);
        sv.addView(s.build());
        root.addView(sv);
    }

    void showHome() {
        current = null;
        root.removeAllViews();
        root.addView(buildHome());
    }

    void back() {
        if (current != null && current.isBusy()) {
            toast("Подождите: идёт работа");
            return;
        }
        showHome();
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {
        if (current == null) super.onBackPressed();
        else back();
    }

    @Override
    @SuppressWarnings("deprecation")
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (current != null) current.onResult(requestCode, resultCode, data);
    }

    // ---------- главное меню ----------

    private View buildHome() {
        LinearLayout page = Ui.column(this, 16);

        // верхняя полоса: монетка «поддержать автора» в правом углу
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        View space = new View(this);
        bar.addView(space, new LinearLayout.LayoutParams(0, 1, 1f));
        bar.addView(buildCoin());
        page.addView(bar, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        page.addView(new View(this), new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));

        // по центру экрана — ник автора
        TextView name = Ui.text(this, "NRO Maker", 16);
        name.setGravity(Gravity.CENTER);
        Ui.add(page, name, 0);
        TextView handle = Ui.text(this, AUTHOR_HANDLE, 30);
        handle.setTypeface(Typeface.DEFAULT_BOLD);
        handle.setGravity(Gravity.CENTER);
        Ui.add(page, handle, 4);

        Ui.add(page, menuButton("Сборка NRO\nиз zip с игрой на Lua",
                v -> showScreen(new NroScreen(this))), 28);
        Ui.add(page, menuButton("Сборка APK\nпроект Android → готовый .apk",
                v -> showScreen(CloudScreen.apk(this))), 8);
        Ui.add(page, menuButton("APK → NRO\nпорт игры из APK",
                v -> showScreen(new ApkToNroScreen(this))), 8);
        Ui.add(page, menuButton("Сборка EXE\nпроект → готовый .exe для Windows",
                v -> showScreen(CloudScreen.exe(this))), 8);

        page.addView(new View(this), new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));
        return page;
    }

    private Button menuButton(String text, View.OnClickListener l) {
        Button b = Ui.button(this, text, l);
        b.setMinHeight(Ui.dp(this, 72));
        return b;
    }

    private View buildCoin() {
        TextView coin = new TextView(this);
        coin.setText("₽");
        coin.setTextSize(22);
        coin.setTypeface(Typeface.DEFAULT_BOLD);
        coin.setTextColor(Color.parseColor("#5B4300"));
        coin.setGravity(Gravity.CENTER);
        GradientDrawable bg = new GradientDrawable();
        bg.setShape(GradientDrawable.OVAL);
        bg.setColor(Color.parseColor("#FFC72C"));
        bg.setStroke(Ui.dp(this, 3), Color.parseColor("#C99700"));
        coin.setBackground(bg);
        int size = Ui.dp(this, 52);
        coin.setLayoutParams(new LinearLayout.LayoutParams(size, size));
        coin.setOnClickListener(v -> showSupport());
        return coin;
    }

    private void showSupport() {
        String msg = "Если приложение пригодилось, можно поддержать автора.\n\n"
                + "Закинуть на чай:\n" + TEA_PHONE + " (" + TEA_BANK + ")\n\n"
                + "Автор: " + AUTHOR_HANDLE;
        new AlertDialog.Builder(this)
                .setTitle("Поддержка автора")
                .setMessage(msg)
                .setPositiveButton("Скопировать номер", (d, w) -> {
                    copyText("Номер для чая", TEA_PHONE);
                    toast("Номер скопирован");
                })
                .setNegativeButton("Закрыть", null)
                .show();
    }
}
