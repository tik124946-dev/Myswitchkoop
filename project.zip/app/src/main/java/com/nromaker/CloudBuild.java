package com.nromaker;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/**
 * Сборка проекта в облаке GitHub прямо с телефона:
 * создаёт приватный репозиторий, кладёт туда проект и сценарий сборки, запускает,
 * ждёт результата и скачивает готовый файл.
 */
public final class CloudBuild {

    public interface Status { void on(String msg); }

    public static final class Result {
        public boolean ok;
        public String failLog = "";
        public File zip;
        public final List<File> files = new ArrayList<>();
    }

    private final GithubClient gh;
    private final Status st;
    private final long pollMs;
    private final long timeoutMs;

    public CloudBuild(GithubClient gh, Status st, long pollMs, long timeoutMs) {
        this.gh = gh;
        this.st = st;
        this.pollMs = pollMs;
        this.timeoutMs = timeoutMs;
    }

    private static String enc(String s) {
        try {
            return java.net.URLEncoder.encode(s, "UTF-8").replace("+", "%20");
        } catch (java.io.UnsupportedEncodingException e) {
            throw new IllegalStateException(e);
        }
    }

    public static String safeRepoName(String name) {
        String n = name == null ? "" : name.trim().replaceAll("[^A-Za-z0-9._-]", "-");
        return n.isEmpty() ? "nro-maker-builds" : n;
    }

    public Result run(String repoName, File projectZip, String workflowYaml, String workflowFile,
                      File outDir) throws Exception {
        if (projectZip.length() > 20L * 1024 * 1024)
            throw new IOException("Проект больше 20 МБ — для сборки с телефона это слишком много. Уберите из архива лишнее (папки build, .gradle, кэши).");
        String repo = safeRepoName(repoName);

        st.on("Проверяю токен…");
        String owner = MiniJson.str(MiniJson.obj(gh.must("GET", "/user", null).json()).get("login"));
        if (owner.isEmpty()) throw new IOException("GitHub не вернул имя пользователя");

        String branch = ensureRepo(owner, repo);

        st.on("Загружаю сценарий сборки…");
        putFile(owner, repo, branch, ".github/workflows/" + workflowFile,
                workflowYaml.getBytes(StandardCharsets.UTF_8), "Add build workflow");
        st.on("Загружаю проект (" + (projectZip.length() / 1024) + " КБ)…");
        putFile(owner, repo, branch, "project.zip", Files.readAllBytes(projectZip.toPath()), "Upload project");

        long before = latestRunId(owner, repo, workflowFile);
        st.on("Запускаю сборку…");
        dispatch(owner, repo, branch, workflowFile);
        long runId = waitForRun(owner, repo, workflowFile, before);

        Result res = new Result();
        String conclusion = pollRun(owner, repo, runId);
        if (!"success".equals(conclusion)) {
            res.ok = false;
            res.failLog = failureLog(owner, repo, runId, conclusion);
            return res;
        }

        st.on("Сборка прошла, скачиваю результат…");
        long artifactId = findArtifact(owner, repo, runId);
        outDir.mkdirs();
        File zip = new File(outDir, "result.zip");
        gh.download("/repos/" + owner + "/" + repo + "/actions/artifacts/" + artifactId + "/zip", zip);
        res.zip = zip;
        extractFlat(zip, new File(outDir, "files"), res.files);
        res.ok = true;
        return res;
    }

    private String ensureRepo(String owner, String repo) throws IOException {
        GithubClient.Resp r = gh.get("/repos/" + owner + "/" + repo);
        if (r.ok()) {
            st.on("Репозиторий " + owner + "/" + repo + " найден");
            String b = MiniJson.str(MiniJson.obj(r.json()).get("default_branch"));
            return b.isEmpty() ? "main" : b;
        }
        if (r.code != 404) throw GithubClient.error(r);
        st.on("Создаю приватный репозиторий " + repo + "…");
        String body = "{\"name\":" + MiniJson.quote(repo)
                + ",\"private\":true,\"auto_init\":true,\"description\":\"Cloud builds from NRO Maker\"}";
        GithubClient.Resp c = gh.must("POST", "/user/repos", body);
        String b = MiniJson.str(MiniJson.obj(c.json()).get("default_branch"));
        return b.isEmpty() ? "main" : b;
    }

    private void putFile(String owner, String repo, String branch, String path, byte[] data,
                         String message) throws Exception {
        String url = "/repos/" + owner + "/" + repo + "/contents/" + path;
        String content = Base64.getEncoder().encodeToString(data);
        for (int attempt = 0; ; attempt++) {
            GithubClient.Resp g = gh.get(url + "?ref=" + enc(branch));
            String sha = g.ok() ? MiniJson.str(MiniJson.obj(g.json()).get("sha")) : "";
            StringBuilder b = new StringBuilder("{\"message\":").append(MiniJson.quote(message))
                    .append(",\"content\":\"").append(content).append("\",\"branch\":")
                    .append(MiniJson.quote(branch));
            if (!sha.isEmpty()) b.append(",\"sha\":").append(MiniJson.quote(sha));
            b.append('}');
            GithubClient.Resp r = gh.call("PUT", url, b.toString());
            if (r.ok()) return;
            if (attempt < 7 && (r.code == 404 || r.code == 409 || r.code == 422)) {
                Thread.sleep(pollMs);
                continue;
            }
            throw GithubClient.error(r);
        }
    }

    private long latestRunId(String owner, String repo, String wf) throws IOException {
        GithubClient.Resp r = gh.get("/repos/" + owner + "/" + repo + "/actions/workflows/" + wf
                + "/runs?per_page=1");
        if (!r.ok()) return 0;
        List<Object> runs = MiniJson.arr(MiniJson.obj(r.json()).get("workflow_runs"));
        return runs.isEmpty() ? 0 : MiniJson.num(MiniJson.obj(runs.get(0)).get("id"));
    }

    private void dispatch(String owner, String repo, String branch, String wf) throws Exception {
        String url = "/repos/" + owner + "/" + repo + "/actions/workflows/" + wf + "/dispatches";
        String body = "{\"ref\":" + MiniJson.quote(branch) + "}";
        for (int attempt = 0; ; attempt++) {
            GithubClient.Resp r = gh.call("POST", url, body);
            if (r.ok()) return;
            // сразу после загрузки файла GitHub ещё несколько секунд не «видит» сценарий
            if (attempt < 20 && (r.code == 404 || r.code == 422)) {
                Thread.sleep(pollMs);
                continue;
            }
            throw GithubClient.error(r);
        }
    }

    private long waitForRun(String owner, String repo, String wf, long before) throws Exception {
        for (int i = 0; i < 40; i++) {
            GithubClient.Resp r = gh.get("/repos/" + owner + "/" + repo + "/actions/workflows/" + wf
                    + "/runs?event=workflow_dispatch&per_page=5");
            if (r.ok()) {
                long best = 0;
                for (Object o : MiniJson.arr(MiniJson.obj(r.json()).get("workflow_runs"))) {
                    long id = MiniJson.num(MiniJson.obj(o).get("id"));
                    if (id > before && id > best) best = id;
                }
                if (best != 0) return best;
            }
            Thread.sleep(pollMs);
        }
        throw new IOException("Сборка не появилась в списке запусков. Проверьте вкладку Actions в репозитории.");
    }

    private static String clock(long ms) {
        long s = ms / 1000;
        return String.format("%d:%02d", s / 60, s % 60);
    }

    private String pollRun(String owner, String repo, long runId) throws Exception {
        long start = System.currentTimeMillis();
        while (true) {
            if (System.currentTimeMillis() - start > timeoutMs)
                throw new IOException("Сборка идёт слишком долго (больше " + (timeoutMs / 60000)
                        + " мин). Проверьте вкладку Actions в репозитории.");
            GithubClient.Resp r = gh.get("/repos/" + owner + "/" + repo + "/actions/runs/" + runId);
            if (r.ok()) {
                Map<String, Object> run = MiniJson.obj(r.json());
                String status = MiniJson.str(run.get("status"));
                if ("completed".equals(status)) return MiniJson.str(run.get("conclusion"));
                st.on("Сборка идёт: " + currentStep(owner, repo, runId, status) + " ("
                        + clock(System.currentTimeMillis() - start) + ")");
            }
            Thread.sleep(pollMs);
        }
    }

    private String currentStep(String owner, String repo, long runId, String status) {
        if ("queued".equals(status) || "waiting".equals(status) || "pending".equals(status))
            return "ожидание сервера";
        try {
            GithubClient.Resp r = gh.get("/repos/" + owner + "/" + repo + "/actions/runs/" + runId + "/jobs");
            if (r.ok()) {
                for (Object j : MiniJson.arr(MiniJson.obj(r.json()).get("jobs"))) {
                    for (Object s : MiniJson.arr(MiniJson.obj(j).get("steps"))) {
                        Map<String, Object> step = MiniJson.obj(s);
                        if ("in_progress".equals(MiniJson.str(step.get("status"))))
                            return MiniJson.str(step.get("name"));
                    }
                }
            }
        } catch (IOException ignored) { }
        return "выполняется";
    }

    private String failureLog(String owner, String repo, long runId, String conclusion) {
        StringBuilder out = new StringBuilder("Сборка завершилась с результатом: " + conclusion + "\n");
        try {
            GithubClient.Resp r = gh.get("/repos/" + owner + "/" + repo + "/actions/runs/" + runId + "/jobs");
            if (!r.ok()) return out.toString();
            for (Object j : MiniJson.arr(MiniJson.obj(r.json()).get("jobs"))) {
                Map<String, Object> job = MiniJson.obj(j);
                if (!"failure".equals(MiniJson.str(job.get("conclusion")))) continue;
                for (Object s : MiniJson.arr(job.get("steps"))) {
                    Map<String, Object> step = MiniJson.obj(s);
                    if ("failure".equals(MiniJson.str(step.get("conclusion"))))
                        out.append("Упал шаг: ").append(MiniJson.str(step.get("name"))).append('\n');
                }
                String text = gh.downloadText("/repos/" + owner + "/" + repo + "/actions/jobs/"
                        + MiniJson.num(job.get("id")) + "/logs");
                String[] lines = text.split("\r?\n");
                int from = Math.max(0, lines.length - 40);
                out.append("--- последние строки лога ---\n");
                for (int i = from; i < lines.length; i++)
                    out.append(lines[i].replaceFirst("^\\S+Z\\s", "")).append('\n');
                break;
            }
        } catch (IOException e) {
            out.append("(не удалось получить лог: ").append(e.getMessage()).append(")\n");
        }
        return out.toString();
    }

    private long findArtifact(String owner, String repo, long runId) throws Exception {
        for (int i = 0; i < 10; i++) {
            GithubClient.Resp r = gh.get("/repos/" + owner + "/" + repo + "/actions/runs/" + runId + "/artifacts");
            if (r.ok()) {
                for (Object a : MiniJson.arr(MiniJson.obj(r.json()).get("artifacts"))) {
                    Map<String, Object> art = MiniJson.obj(a);
                    if ("result".equals(MiniJson.str(art.get("name")))) return MiniJson.num(art.get("id"));
                }
            }
            Thread.sleep(pollMs);
        }
        throw new IOException("Сборка прошла, но результат (artifact «result») не найден.");
    }

    /** Распаковывает zip в одну папку, используя только имена файлов (защита от zip-slip). */
    static void extractFlat(File zip, File dest, List<File> out) throws IOException {
        dest.mkdirs();
        try (ZipInputStream z = new ZipInputStream(new FileInputStream(zip), StandardCharsets.UTF_8)) {
            ZipEntry e;
            byte[] buf = new byte[1 << 16];
            while ((e = z.getNextEntry()) != null) {
                if (e.isDirectory()) continue;
                String name = e.getName().replace('\\', '/');
                name = name.substring(name.lastIndexOf('/') + 1);
                if (name.isEmpty() || name.equals(".") || name.equals("..")) continue;
                File f = new File(dest, name);
                try (OutputStream os = new FileOutputStream(f)) {
                    int n;
                    while ((n = z.read(buf)) > 0) os.write(buf, 0, n);
                }
                out.add(f);
            }
        }
    }
}
