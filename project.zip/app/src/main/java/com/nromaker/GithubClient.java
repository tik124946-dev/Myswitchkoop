package com.nromaker;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

/** Минимальный клиент GitHub REST API на HttpURLConnection. */
public final class GithubClient {

    public static final class Resp {
        public final int code;
        public final String body;
        public final String location;
        Resp(int code, String body, String location) { this.code = code; this.body = body; this.location = location; }
        public boolean ok() { return code >= 200 && code < 300; }
        public Object json() { return body.isEmpty() ? null : MiniJson.parse(body); }
    }

    public static final class ApiException extends IOException {
        public final int code;
        public ApiException(int code, String msg) { super(msg); this.code = code; }
    }

    private final String base;
    private final String token;

    public GithubClient(String base, String token) {
        this.base = base.endsWith("/") ? base.substring(0, base.length() - 1) : base;
        this.token = token;
    }

    private HttpURLConnection open(String method, String url, boolean auth) throws IOException {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setRequestMethod(method);
        c.setInstanceFollowRedirects(false); // редиректы обрабатываем сами, токен на чужой хост не уходит
        c.setConnectTimeout(30000);
        c.setReadTimeout(120000);
        c.setRequestProperty("User-Agent", "NroMaker");
        if (auth) {
            c.setRequestProperty("Authorization", "Bearer " + token);
            c.setRequestProperty("Accept", "application/vnd.github+json");
            c.setRequestProperty("X-GitHub-Api-Version", "2022-11-28");
        }
        return c;
    }

    private static byte[] readAll(InputStream in) throws IOException {
        if (in == null) return new byte[0];
        try (InputStream i = in) {
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            byte[] buf = new byte[1 << 14];
            int n;
            while ((n = i.read(buf)) > 0) bos.write(buf, 0, n);
            return bos.toByteArray();
        }
    }

    /** Запрос к API. path начинается с '/'. body может быть null. */
    public Resp call(String method, String path, String body) throws IOException {
        HttpURLConnection c = open(method, base + path, true);
        if (body != null) {
            c.setDoOutput(true);
            c.setRequestProperty("Content-Type", "application/json");
            byte[] data = body.getBytes(StandardCharsets.UTF_8);
            c.setFixedLengthStreamingMode(data.length);
            try (OutputStream os = c.getOutputStream()) { os.write(data); }
        }
        int code = c.getResponseCode();
        InputStream in = code >= 400 ? c.getErrorStream() : c.getInputStream();
        String text = new String(readAll(in), StandardCharsets.UTF_8);
        return new Resp(code, text, c.getHeaderField("Location"));
    }

    public Resp get(String path) throws IOException { return call("GET", path, null); }

    /** Вызов, который обязан вернуть 2xx, иначе ApiException с понятным текстом. */
    public Resp must(String method, String path, String body) throws IOException {
        Resp r = call(method, path, body);
        if (!r.ok()) throw error(r);
        return r;
    }

    public static ApiException error(Resp r) {
        String msg = "";
        try {
            msg = MiniJson.str(MiniJson.obj(r.json()).get("message"));
        } catch (RuntimeException ignored) { }
        if (msg.isEmpty()) msg = r.body.length() > 200 ? r.body.substring(0, 200) : r.body;
        String hint = "";
        if (r.code == 401) hint = " (неверный или просроченный токен)";
        else if (r.code == 403) hint = " (у токена не хватает прав или превышен лимит)";
        return new ApiException(r.code, "GitHub вернул " + r.code + ": " + msg + hint);
    }

    /** Скачивает файл с эндпоинта API, который отвечает редиректом на временную ссылку. */
    public void download(String path, File dest) throws IOException {
        HttpURLConnection c = open("GET", base + path, true);
        int code = c.getResponseCode();
        if (code >= 300 && code < 400) {
            String loc = c.getHeaderField("Location");
            c.disconnect();
            if (loc == null) throw new ApiException(code, "Редирект без адреса");
            c = open("GET", loc, false); // без токена!
            code = c.getResponseCode();
        }
        if (code < 200 || code >= 300) {
            String text = new String(readAll(c.getErrorStream()), StandardCharsets.UTF_8);
            throw new ApiException(code, "Не удалось скачать файл: " + code + " " + text);
        }
        try (InputStream in = c.getInputStream(); OutputStream out = new FileOutputStream(dest)) {
            byte[] buf = new byte[1 << 16];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
        }
    }

    /** Скачивает текст (логи) с редиректом. */
    public String downloadText(String path) throws IOException {
        HttpURLConnection c = open("GET", base + path, true);
        int code = c.getResponseCode();
        if (code >= 300 && code < 400) {
            String loc = c.getHeaderField("Location");
            c.disconnect();
            if (loc == null) return "";
            c = open("GET", loc, false);
            code = c.getResponseCode();
        }
        if (code < 200 || code >= 300) return "";
        return new String(readAll(c.getInputStream()), StandardCharsets.UTF_8);
    }
}
