package com.nromaker;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;

import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

/** Встроенный движок LÖVE Potion (кладётся в assets при сборке на GitHub) и общие операции с ним. */
final class EngineRuntime {

    private EngineRuntime() {}

    static byte[] load(Context c) throws IOException {
        try (InputStream in = c.getAssets().open("lovepotion.nro")) {
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            byte[] buf = new byte[1 << 16];
            int n;
            while ((n = in.read(buf)) > 0) bos.write(buf, 0, n);
            return bos.toByteArray();
        } catch (FileNotFoundException e) {
            throw new IllegalStateException("В приложении нет движка lovepotion.nro. "
                    + "Соберите APK через workflow из build.yml — он собирает движок сам.");
        }
    }

    /** Собирает .nro: движок + игра (.love) и сохраняет по адресу out. Возвращает размер в байтах. */
    static long writeNro(Context c, Uri out, byte[] nacp, byte[] icon, File love,
                         RomFs.Progress progress) throws IOException {
        byte[] runtime = load(c);
        OutputStream raw = c.getContentResolver().openOutputStream(out, "wt");
        if (raw == null) throw new IOException("Не удалось открыть файл для записи");
        try (OutputStream os = new BufferedOutputStream(raw, 1 << 16)) {
            NroBuilder.writeWithRuntime(runtime, nacp, icon, love, os, progress);
        }
        return runtime.length + love.length();
    }

    /** Любую картинку превращает в JPEG 256x256 — такой формат иконки ждёт Switch. */
    static byte[] iconJpeg(byte[] image) {
        Bitmap bmp = BitmapFactory.decodeByteArray(image, 0, image.length);
        if (bmp == null) throw new IllegalArgumentException("Не удалось прочитать иконку");
        Bitmap scaled = Bitmap.createScaledBitmap(bmp, 256, 256, true);
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        scaled.compress(Bitmap.CompressFormat.JPEG, 92, bos);
        return bos.toByteArray();
    }
}
