plugins {
    id("com.android.application")
}

android {
    namespace = "com.nromaker"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.nromaker"
        minSdk = 26
        targetSdk = 34
        versionCode = 3
        versionName = "3.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
